let a=parseFloat(prompt('digite um numero'))

if(a%2==0){
    alert('esse numero é par')
}else{
    alert('esse numero é impar')
}