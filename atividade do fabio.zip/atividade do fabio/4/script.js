  let a=parseFloat(prompt('saldo:'))
  let saldo=(a*0.01)
  let total=(a+saldo);
    alert('valor com 1% a mais='+total)
