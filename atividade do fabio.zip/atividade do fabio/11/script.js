let a=parseFloat(prompt('numero 1°'))
let b=parseFloat(prompt('numero 2°'))
let c=parseFloat(prompt('numero 3°'))
let media=(a+b+c)/3;
if(media>=7){
    alert('APROVADO')
}else{
    alert('REPROVADO')
}