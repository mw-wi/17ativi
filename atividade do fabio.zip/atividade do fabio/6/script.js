let a=parseFloat(prompt('digite a temperatura:'))
let graus=-17;
let valor=a*graus;
alert('transformação e igual a='+valor);