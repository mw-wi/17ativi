let a=parseFloat(prompt('1°'))
let b=parseFloat(prompt('2°'))
let c=parseFloat(prompt('3°'))
let maior=a;
 if(b>maior){
    maior=b;
 }
 if(c>maior){
    maior=c;
 }
 alert('numero maior é ='+maior)