let a=parseFloat(prompt('digite o valor em dolar'));
let dolar=5.80;
let valor=(a*dolar);
alert('valor em reais='+valor)
