let a=parseFloat(prompt('digite um numero:'))
if(a>0){
    alert('esse numero é positivo')
}else{
    alert('ese numero é negativo')
}