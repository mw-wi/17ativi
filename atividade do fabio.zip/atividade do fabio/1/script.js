   let a=parseFloat(prompt("digite o 1° "))
   let b=parseFloat(prompt("digite o 2° "))
   let c=parseFloat(prompt("digite o 3° "))

    let media=((a+b+c)/3);
    alert("media aritimetica dos numeros="+media)