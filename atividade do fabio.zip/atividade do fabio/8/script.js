let a=parseFloat(prompt('salario:'))
let b=parseFloat(prompt('aumento:'))
let valor=b/100;
let valor2=a*valor;
let total=a+valor2;
alert('aumento:'+total)